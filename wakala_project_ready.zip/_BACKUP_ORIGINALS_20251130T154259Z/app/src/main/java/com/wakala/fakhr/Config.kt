package com.wakala.fakhr

object Config {
    // Set BASE_URL at runtime if needed, or update BuildConfig.BACKEND_BASE_URL in Gradle.
    var BASE_URL: String = "http://127.0.0.1:5000/"
}
