
This folder contains analysis-only AI components (HybridGamePredictorV2) used for game analytics.
- It computes activity scores, top-3 active options (analysis), and time-signature based boosts.
- It is NOT a winner predictor and must not be used to make outcome predictions.
- Training job will produce RF fallback model for analytics and time_signature.json for heatmap.
