
package com.wakala.fakhr.overlay

import android.content.Context
import android.graphics.Bitmap

object OCRBridge {
    // placeholder helper: actual MLKit usage implemented in OCRProcessor.kt
    fun analyzeBitmap(ctx: Context, bmp: Bitmap): String {
        // return recognized text (placeholder)
        return ""
    }
}
